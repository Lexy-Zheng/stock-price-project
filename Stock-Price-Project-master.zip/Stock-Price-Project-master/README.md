# Stock-Price-Prediction-and-Trade-Simulation

>Zhuofan Zhang zhuofan.zhang@marylandsmith.umd.edu <br>
>Shiyu Shi shiyu.shi@marylandsmith.umd.edu <br>
>Qing Yan qing.yan@marylandsmith.umd.edu <br>
>Hui He hui.he@marylandsmith.umd.edu <br>
>Yueheng Wang yueheng.wang@marylandsmith.umd.edu <br>
>Xiaoya Wang xiaoya.wang@marylandsmith.umd.edu <br>

Our group conducts numerical analysis on the leading enterprises of both technology Industry, entertainment industry and pharmaceutical industry. To be more specific, we analyze the stock behavior of Apple, Netflix and Pfizer mainly showing our work on Pfizer in this notebook as an example. <br>
Numerical analysis based on historical stock data is also known as technical analysis. Technical analysis can predict the trend of prices and can further decide on investment strategyby by studying the past financial market information. We assume that history will repeat itself. As long as we mine historical data for patterns that repeat themselves, we can use this pattern to design profitable strategies. Therefore, we conduct stock forecast by technical analysis and try to give some suggestions on quantitative investment. In this project, we accomplish this goal by conducting Data Extraction,Transformation and Load, predictive modeling with Machine Learning algorithms, Deep Learning and Neural Networ and trade simulation.<br>
As a result, we achieved up to 49% return ratio with our project.<br>
